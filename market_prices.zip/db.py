"""SQLite cache for mandi prices."""
import os
import sqlite3

DB_PATH = os.getenv("PRICES_DB", "market_prices.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_conn() as conn:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS prices (
                state TEXT, district TEXT, market TEXT, commodity TEXT,
                variety TEXT, grade TEXT, arrival_date TEXT,
                min_price REAL, max_price REAL, modal_price REAL,
                PRIMARY KEY (state, district, market, commodity,
                             variety, grade, arrival_date)
            )"""
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_lookup "
            "ON prices (state, district, market, commodity)"
        )
        conn.execute(
            "CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)"
        )
