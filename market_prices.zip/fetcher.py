"""Pulls raw records from the data.gov.in Agmarknet API."""
import os
import time

import requests

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Resource: "Current Daily Price of Various Commodities from Various Markets (Mandi)"
# Verify this ID on data.gov.in if requests return 404.
RESOURCE_ID = os.getenv("MANDI_RESOURCE_ID", "9ef84268-d588-465a-a308-a864a43d0070")
API_URL = f"https://api.data.gov.in/resource/{RESOURCE_ID}"
PAGE_SIZE = 1000


def fetch_all(state=None, max_records=50000):
    api_key = os.getenv("DATA_GOV_API_KEY")
    if not api_key:
        raise RuntimeError("Set DATA_GOV_API_KEY in your environment or .env file")

    records, offset = [], 0
    while offset < max_records:
        params = {
            "api-key": api_key,
            "format": "json",
            "limit": PAGE_SIZE,
            "offset": offset,
        }
        if state:
            params["filters[state.keyword]"] = state

        for attempt in range(3):  # the government API is flaky: retry
            try:
                resp = requests.get(API_URL, params=params, timeout=30)
                resp.raise_for_status()
                break
            except requests.RequestException:
                if attempt == 2:
                    raise
                time.sleep(2 ** attempt)

        batch = resp.json().get("records", [])
        records.extend(batch)
        if len(batch) < PAGE_SIZE:
            break
        offset += PAGE_SIZE
    return records
