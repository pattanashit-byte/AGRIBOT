"""Business logic: refresh the cache and query it."""
from datetime import datetime

from .db import get_conn, init_db
from .fetcher import fetch_all


def _to_iso(d):
    try:
        return datetime.strptime(d, "%d/%m/%Y").strftime("%Y-%m-%d")
    except (ValueError, TypeError):
        return None


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _clean(x):
    return (x or "").strip()


# ---------- refresh ----------
def refresh_prices(state=None):
    """Fetch from the API and upsert into SQLite. Returns rows stored."""
    init_db()
    rows = []
    for r in fetch_all(state=state):
        date = _to_iso(r.get("arrival_date"))
        if not date:
            continue
        rows.append((
            _clean(r.get("state")), _clean(r.get("district")),
            _clean(r.get("market")), _clean(r.get("commodity")),
            _clean(r.get("variety")), _clean(r.get("grade")), date,
            _num(r.get("min_price")), _num(r.get("max_price")),
            _num(r.get("modal_price")),
        ))
    with get_conn() as conn:
        conn.executemany(
            "INSERT OR REPLACE INTO prices VALUES (?,?,?,?,?,?,?,?,?,?)", rows
        )
        conn.execute(
            "INSERT OR REPLACE INTO meta VALUES ('last_refresh', ?)",
            (datetime.now().isoformat(timespec="seconds"),),
        )
    return len(rows)


def last_refresh():
    init_db()
    with get_conn() as conn:
        row = conn.execute("SELECT value FROM meta WHERE key='last_refresh'").fetchone()
    return row[0] if row else None


# ---------- dropdown data ----------
def _distinct(col, filters):
    """filters: dict of column -> value (case-insensitive)."""
    init_db()
    where, params = "", []
    conds = [f"{k}=? COLLATE NOCASE" for k, v in filters.items() if v]
    params = [v for v in filters.values() if v]
    if conds:
        where = "WHERE " + " AND ".join(conds)
    with get_conn() as conn:
        cur = conn.execute(
            f"SELECT DISTINCT {col} FROM prices {where} ORDER BY {col}", params
        )
        return [r[0] for r in cur if r[0]]


def get_states():
    return _distinct("state", {})


def get_districts(state):
    return _distinct("district", {"state": state})


def get_markets(state, district):
    return _distinct("market", {"state": state, "district": district})


def get_commodities(state=None, district=None, market=None):
    return _distinct(
        "commodity", {"state": state, "district": district, "market": market}
    )


def search_commodities(query, limit=15):
    init_db()
    with get_conn() as conn:
        cur = conn.execute(
            "SELECT DISTINCT commodity FROM prices WHERE commodity LIKE ? "
            "ORDER BY commodity LIMIT ?",
            (f"%{query.strip()}%", limit),
        )
        return [r[0] for r in cur]


# ---------- prices ----------
def _with_per_kg(row):
    d = dict(row)
    for k in ("min_price", "max_price", "modal_price"):
        d[k + "_per_kg"] = round(d[k] / 100, 2) if d[k] is not None else None
    return d


def get_latest_prices(state, district, market, commodity):
    """Most recent available day for this mandi + crop (all varieties)."""
    init_db()
    base = (
        "state=? COLLATE NOCASE AND district=? COLLATE NOCASE AND "
        "market=? COLLATE NOCASE AND commodity=? COLLATE NOCASE"
    )
    params = (state, district, market, commodity)
    with get_conn() as conn:
        latest = conn.execute(
            f"SELECT MAX(arrival_date) FROM prices WHERE {base}", params
        ).fetchone()[0]
        if not latest:
            return []
        rows = conn.execute(
            f"SELECT * FROM prices WHERE {base} AND arrival_date=? ORDER BY variety",
            params + (latest,),
        ).fetchall()
    return [_with_per_kg(r) for r in rows]


def get_trend(state, district, market, commodity, days=30):
    """Average modal price per day for a chart (₹/quintal)."""
    init_db()
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT arrival_date, ROUND(AVG(modal_price), 2) AS modal_price
               FROM prices
               WHERE state=? COLLATE NOCASE AND district=? COLLATE NOCASE
                 AND market=? COLLATE NOCASE AND commodity=? COLLATE NOCASE
                 AND arrival_date >= date('now', ?)
               GROUP BY arrival_date ORDER BY arrival_date""",
            (state, district, market, commodity, f"-{int(days)} days"),
        ).fetchall()
    return [dict(r) for r in rows]


def quick_price(commodity, state):
    """One-line answer for the chatbot / crop recommendation module."""
    init_db()
    with get_conn() as conn:
        row = conn.execute(
            """SELECT arrival_date, ROUND(AVG(modal_price),0) AS avg_modal,
                      COUNT(DISTINCT market) AS n_markets
               FROM prices
               WHERE commodity=? COLLATE NOCASE AND state=? COLLATE NOCASE
                 AND arrival_date = (SELECT MAX(arrival_date) FROM prices
                                     WHERE commodity=? COLLATE NOCASE
                                       AND state=? COLLATE NOCASE)""",
            (commodity, state, commodity, state),
        ).fetchone()
    if not row or row["avg_modal"] is None:
        return f"No recent price data found for {commodity} in {state}."
    return (
        f"{commodity} in {state} (as of {row['arrival_date']}): about "
        f"₹{int(row['avg_modal'])}/quintal (₹{row['avg_modal']/100:.0f}/kg) "
        f"modal price across {row['n_markets']} market(s)."
    )
