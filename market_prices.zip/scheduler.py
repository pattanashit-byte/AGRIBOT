"""Daily refresh job. Also runnable once:  python -m market_prices.scheduler"""
import logging

from .service import refresh_prices

log = logging.getLogger(__name__)


def safe_refresh():
    try:
        n = refresh_prices()
        log.info("Refreshed %d price rows", n)
    except Exception as e:  # keep serving cached data if the API is down
        log.warning("Price refresh failed, using cached data: %s", e)


def start_scheduler(hour=19, minute=0):
    from apscheduler.schedulers.background import BackgroundScheduler

    sched = BackgroundScheduler(timezone="Asia/Kolkata")
    sched.add_job(safe_refresh, "cron", hour=hour, minute=minute)
    sched.start()
    return sched


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    safe_refresh()
