"""Flask blueprint exposing the price endpoints."""
from flask import Blueprint, jsonify, request

from . import service

bp = Blueprint("prices", __name__, url_prefix="/prices")


@bp.get("/states")
def states():
    return jsonify(service.get_states())


@bp.get("/districts")
def districts():
    return jsonify(service.get_districts(request.args["state"]))


@bp.get("/markets")
def markets():
    return jsonify(service.get_markets(request.args["state"], request.args["district"]))


@bp.get("/commodities")
def commodities():
    q = request.args.get("q")
    if q:  # search-bar autocomplete
        return jsonify(service.search_commodities(q))
    return jsonify(service.get_commodities(
        request.args.get("state"), request.args.get("district"), request.args.get("market")
    ))


@bp.get("/latest")
def latest():
    a = request.args
    data = service.get_latest_prices(a["state"], a["district"], a["market"], a["commodity"])
    return jsonify({"last_refresh": service.last_refresh(), "prices": data})


@bp.get("/trend")
def trend():
    a = request.args
    return jsonify(service.get_trend(
        a["state"], a["district"], a["market"], a["commodity"], int(a.get("days", 30))
    ))
